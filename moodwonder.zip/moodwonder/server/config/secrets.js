module.exports = {
    db: process.env.MONGOHQ_URL || process.env.MONGOLAB_URI || 'mongodb://localhost/moodwonder1',
    //sessionSecret: process.env.SESSION_SECRET || 'Your Session Secret goes here',
    sessionSecret: 'session secret',
    portnumber: 3000,
};
