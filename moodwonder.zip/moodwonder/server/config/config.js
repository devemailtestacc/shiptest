module.exports = {
    //staticUrl: 'http://localhost:3000/'
    staticUrl: 'http://moodwonder.titechnologies.org:9039/',
    fromEmail: 'admin@moodwonder.com',
    adminemail: 'ujjwal.mairh@gmail.com,info@moodwonder.com,kimmo_kauhanen@hotmail.com,bindiya.prakash@titechnologies.in'
};
