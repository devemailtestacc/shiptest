/**
 * TaskConstants
 */

//const keyMirror = require('keymirror');
//
//module.exports = keyMirror({
//  EN: null,
//  FI: null,
//  english: null
//});

import keyMirror from 'keymirror';

export default keyMirror({
  EN: null,
  FI: null,
  english: null
});
