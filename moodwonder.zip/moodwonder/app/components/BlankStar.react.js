import React from 'react';


export default class BlankStar extends React.Component {

  constructor (props) {
      super(props);
  }

  componentDidMount () {

  }

  componentWillUnmount () {

  }

  render () {

      return (
          <i className="icon"></i>
      );
  }

}


