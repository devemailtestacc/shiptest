import alt from 'altInstance';

/**
 * AppActions
 */
class AppActions {

  // check login status and get user type
  checkuser () {
      this.dispatch();
  }

}

export default alt.createActions(AppActions);
