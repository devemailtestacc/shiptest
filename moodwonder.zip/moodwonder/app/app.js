import universalRenderer from './utils/UniversalRenderer';
import alt from 'altInstance';
import routes from 'routes.js';
import html from 'base.html';

export default universalRenderer(alt, routes, html);
