import Alt from 'alt';
// This creates the alt variable in a singleton way
export default new Alt();
